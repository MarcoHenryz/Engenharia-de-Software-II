package codigos;

public class LadoInvalidoException extends Exception {
	
	public LadoInvalidoException(String msg){
		super(msg);
	}

}
